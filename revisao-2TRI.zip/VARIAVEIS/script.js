// # ID ou indentificador
// . Class ou classe CSS
const comidas = document.querySelector('.comidas');

const comida1 = prompt('digite sua comida n°1 ')

comidas.innerText = comida1;

alert("Vocé gosta de: " + comida1)