// VARIAVEIS UNITARIAS 
const nome = 'nino'
const nome2 = 'kabrinha'
const nome3 = 'peçinha'



// VARIAVEIS DE ARRAY
const nomes = ['nino', 'kabrinha', 'peçinha']
console.log(nomes)
console.log(nomes[2])
nomes[10] = 'buzeira'
console.log(nomes[10])